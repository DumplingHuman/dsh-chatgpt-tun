import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type HelmLocaleKey } from './app/app.js';
export * from './app/app.js';
export * from './app/adapter.js';
export * from './app/components/session-activity.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'dsh.chatgptHelm': HelmLocaleKey;
    }
}
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
