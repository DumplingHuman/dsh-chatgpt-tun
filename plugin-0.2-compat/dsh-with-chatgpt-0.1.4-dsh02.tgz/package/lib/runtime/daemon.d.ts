import { type CoreConfigOverride } from '@beforewave/agent-helm';
export type DaemonMode = 'auto' | 'external' | 'managed';
export type DaemonLaunchPlan = 'attach' | 'spawn' | 'idle';
export declare function resolveDaemonLaunchPlan(mode: DaemonMode, available: boolean): DaemonLaunchPlan;
export interface ManagedDaemonOptions {
    socket: string;
    override: CoreConfigOverride;
    lifecycleOwner?: string;
    startupTimeoutMs?: number;
    env?: NodeJS.ProcessEnv;
    onStdout?: (chunk: string) => void;
    onStderr?: (chunk: string) => void;
}
export declare class ManagedDaemon {
    #private;
    readonly options: ManagedDaemonOptions;
    constructor(options: ManagedDaemonOptions);
    get pid(): number | undefined;
    get running(): boolean;
    start(): Promise<void>;
    stop(): Promise<void>;
}
