import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ChatGPTHelmRuntime } from './runtime.js';
export declare const HELM_UI_STATUS_PATH = "/api/dsh-with-chatgpt/status";
export declare const HELM_SESSION_API_PATH = "/api/dsh-with-chatgpt/sessions";
export declare function handleHelmStatusRequest(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse): Promise<void>;
export declare function handleHelmSessionRequest(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse): Promise<void>;
export declare function handleHelmApiRequest(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse): Promise<boolean>;
