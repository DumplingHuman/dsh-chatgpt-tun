import { AdapterRpcClient, type ChatSessionActivity, type ChatSessionSummary, type ChatSessionSummaryPage, type ChatSessionTimelineItem, type CoreConfigOverride, type DelegatedSession, type ExternalUserAccess, type TunnelSetupInput } from '@beforewave/agent-helm';
import type { ChatGPTHelmHostAdapter, ChatGPTHelmRuntimeLogger } from './contracts.js';
import { type DaemonMode } from './daemon.js';
import { type HelmUiDependencyName, type HelmUiStatus } from './status.js';
export interface ChatGPTHelmRuntimeOptions {
    daemonMode: DaemonMode;
    launcherOverride: CoreConfigOverride;
    host: ChatGPTHelmHostAdapter;
    logger?: ChatGPTHelmRuntimeLogger;
}
export interface ChatGPTHelmRuntimeStatus extends HelmUiStatus {
    running: boolean;
    lifecycleManaged: boolean;
    coreSocket?: string;
}
export declare class ChatGPTHelmRuntime {
    #private;
    readonly options: ChatGPTHelmRuntimeOptions;
    constructor(options: ChatGPTHelmRuntimeOptions);
    get running(): boolean;
    get rpc(): AdapterRpcClient;
    start(): Promise<void>;
    stop(): Promise<void>;
    getStatus(): Promise<ChatGPTHelmRuntimeStatus>;
    installDependency(name: HelmUiDependencyName): Promise<ChatGPTHelmRuntimeStatus>;
    configureTunnel(input: TunnelSetupInput): Promise<ChatGPTHelmRuntimeStatus>;
    setCoreEnabled(enabled: boolean): Promise<ChatGPTHelmRuntimeStatus>;
    setLocalMcpEnabled(enabled: boolean): Promise<ChatGPTHelmRuntimeStatus>;
    setExternalAgentLspEnabled(enabled: boolean): Promise<ChatGPTHelmRuntimeStatus>;
    setExternalUserAccess(access: Partial<ExternalUserAccess>): Promise<ChatGPTHelmRuntimeStatus>;
    getSessionPage(cursor?: string, limit?: number): Promise<ChatSessionSummaryPage>;
    getSession(id: string): Promise<ChatSessionSummary | undefined>;
    getSessionTimeline(id: string): Promise<ChatSessionTimelineItem[]>;
    getSessionActivity(id: string): Promise<ChatSessionActivity[]>;
    getSessionDelegations(id: string): Promise<DelegatedSession[]>;
}
