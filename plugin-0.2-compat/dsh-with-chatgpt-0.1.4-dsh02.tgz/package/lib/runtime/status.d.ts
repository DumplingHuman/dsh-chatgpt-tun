import { type AdapterRpcClient, type ExternalCapabilityPolicy, type ExternalUserAccess } from '@beforewave/agent-helm';
import type { LocalMcpRuntime } from './contracts.js';
export type HelmUiDependencyName = 'serena' | 'tunnelClient';
export type HelmUiRuntimeState = 'running' | 'ready' | 'stopped' | 'missing-config' | 'disabled' | 'unavailable';
export interface HelmUiStatus {
    core: {
        state: HelmUiRuntimeState;
        enabled?: boolean;
        configurable?: boolean;
        message?: string;
    };
    dependencies: {
        serena: {
            state: HelmUiRuntimeState;
            command: string;
            installUrl?: string;
            installCommand?: string;
        };
        tunnelClient: {
            state: HelmUiRuntimeState;
            command: string;
            installUrl?: string;
            installCommand?: string;
        };
    };
    tunnel: {
        state: HelmUiRuntimeState;
        enabled?: boolean;
        configured?: boolean;
        tunnelId?: string;
        organizationId?: string;
        apiKeyConfigured?: boolean;
        proxyConfigured?: boolean;
        proxyUrl?: string;
        error?: {
            code: string;
            message: string;
        };
        missingEnvironment?: string[];
        adminUrl?: string;
        logsUrl?: string;
    };
    localMcp: {
        state: HelmUiRuntimeState;
        url?: string;
        message?: string;
    };
    externalAgentLsp: {
        state: HelmUiRuntimeState;
        enabled: boolean;
        configurable: boolean;
    };
    externalCapabilities: ExternalCapabilityPolicy;
    externalUserAccess: ExternalUserAccess;
    effectiveExternalAccess: ExternalUserAccess;
}
export declare function coreDependencyStatus(health: Record<string, unknown>): HelmUiStatus['dependencies'];
export declare function resolveHelmUiStatus(rpc: AdapterRpcClient, bridge?: LocalMcpRuntime, expectedLifecycleOwner?: string): Promise<HelmUiStatus>;
